% ===========================================
%  
%  2024, ModelFLOWs group & NuMath group, UPM
%  
%  This program is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
%  
%  This program is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
%  
%  You should have received a copy of the GNU General Public License
%  along with this program.  If not, see <http://www.gnu.org/licenses/>.
% ===========================================

close all; clear all; clc
mkdir Ideal/STL


%% Load your STL file

initialMesh = stlread("./Ideal/Ideal.stl");

% Code in meters, scaling if necessary
scaling = 1e-3;
data = initialMesh.Points*scaling;
connectivity = initialMesh.ConnectivityList;

% Function taken from: 
% https://es.mathworks.com/matlabcentral/fileexchange/78489-stl-file-reader-both-ascii-bin-auto-detection?s_tid=srchtitle
% -----------------------------------------------------------------------------
figure(1); hold on 
view([10, -10, 10])
trimesh(connectivity, data(:, 1), data(:, 2), data(:, 3), 'EdgeColor','k', 'FaceColor',[0.8 0.8 0.8]);
daspect([1 1 1])
grid on
set(gca,'ZDir','reverse')
set(gcf,'Position',[50 100 400 600])
hold off
% -----------------------------------------------------------------------------


%% Classification of vertices

tolerance_mesh = 1e-10; % Tolerance for spatial points
a = 0.02; % Short semiaxis of semi-ellipsoid
r_move = a - 0.0024; % Radius in base plane where points start to move (after tubes)

% Detect points on plane z=0 and make correction
atBasePlane   = find( abs(data(:, 3)) <= tolerance_mesh);
data(atBasePlane,3) = 0;

% Sort points for moving and static parts
belowBasePlane = find( data(:, 3) >  tolerance_mesh);
uponBasePlane  = find( data(:, 3) <  -tolerance_mesh);

r = sqrt(data(:, 1).^2  + data(:, 2).^2);

atBasePlane_Moving = find(abs(data(:, 3)) <= tolerance_mesh & abs(r) > r_move & abs(r) < a);
atBasePlane_Edge = find(abs(data(:, 3)) <= tolerance_mesh & abs(r) >= a);

% Remove nodes in the base from the edge
atBasePlane = setdiff(atBasePlane, atBasePlane_Edge);

% Complete the shell of the ventricle
belowBasePlane = setdiff(belowBasePlane, atBasePlane);
belowBasePlane = [belowBasePlane; atBasePlane_Edge];

% Remove nodes in the base that are moving
atBasePlane = setdiff(atBasePlane, atBasePlane_Moving);

% -----------------------------------------------------------------------------
% Yellow: Moving
figure(2); hold on 
view([10, -10, 10])
trimesh(connectivity, data(:, 1), data(:, 2), data(:, 3), 'EdgeColor','k', 'FaceColor',[0.8 0.8 0.8]);
daspect([1 1 1])
grid on
set(gca,'ZDir','reverse')
set(gcf,'Position',[50 100 400 600])
scatter3(data(belowBasePlane, 1), ...
         data(belowBasePlane, 2), ...
         data(belowBasePlane, 3), 'y','filled')
scatter3(data(atBasePlane_Moving, 1), ...
         data(atBasePlane_Moving, 2), ...
         data(atBasePlane_Moving, 3), 'y','filled')

% Blue: Static
scatter3(data(atBasePlane, 1), ...
         data(atBasePlane, 2), ...
         data(atBasePlane, 3), 'b','filled')
scatter3(data(uponBasePlane, 1), ...
         data(uponBasePlane, 2), ...
         data(uponBasePlane, 3), 'b','filled')
hold off
% -----------------------------------------------------------------------------


%% Flow rate chart

RawData = readmatrix("./Ideal/flowrate_chart.csv");
T_period = 1;
Nt = 2001;

% Normalize time with period
timeH     = RawData(:, 1)/T_period;
flowRateH = RawData(:, 2); 

% -----------------------------------------------------------------------------
% Interpolation to obtain equidistant fine database
tt=linspace(timeH(1),timeH(end),Nt);
fR = interp1(timeH,flowRateH,tt,'spline');

% -----------------------------------------------------------------------------
% Correction of flow rate difference between diastole and systole
FF = griddedInterpolant(tt, fR);
F = @(tau) FF(tau);
index_sys = find(fR<0);
volume_diff = abs(integral(F,tt(1),tt(end)));

while volume_diff > 1e-3
    
    volume_sum = volume_diff/(tt(end-1)-tt(index_sys(1)));
    
    if abs(fR(index_sys(1):end-1))<volume_sum
        ('Positive flow rate introduced in systole')
        return
    end
    fR(index_sys(1):end-1)=fR(index_sys(1):end-1)+volume_sum;
    
    FF = griddedInterpolant(tt, fR);
    F = @(tau) FF(tau);

    if abs(integral(F,tt(1),tt(end))) > volume_diff
        ('Converged')
        break
    end

    volume_diff = abs(integral(F,tt(1),tt(end)));
    
end

% -----------------------------------------------------------------------------
figure(3); hold on
plot(timeH,flowRateH, 'bo','MarkerSize',5,'MarkerFaceColor','b')
plot(tt,fR, 'r-','LineWidth',2)
xlabel('$t^{*}$','Interpreter','latex'); ylabel('Ventricular flow rate [ml/s]','Interpreter','latex')
legend('Original','Interpolated')
hold off
% -----------------------------------------------------------------------------


%% Contruct volume with the desired time step

% Number of STL files to create
nS = 500;

V0 = 67.02; % Initial volume of ventricle [ml]

t = linspace(tt(1), tt(end), nS);

VolumeVariation = zeros(1, nS);
for i = 1:nS
    VolumeVariation(i) = integral(F, t(1), t(i));
end

Volume_inM3 = (V0 + VolumeVariation) * 1e-6;

% End-systolic volume is V0, and equal to early diastole: 
% b = 8 cm = 80 mm
% a = 2 cm = 20 mm 
% Ratio of dimensions will remain constant: k = a/b = 1/4
% V(t) = 2/3 * pi * k^2 * c^3
min_a = 0.02; min_b = 0.08; k = 1/4;

b_t = (3.0/2.0/pi/k^2 * Volume_inM3).^(1/3);
a_t = k*b_t;

minLVVol = min(Volume_inM3);
maxLVVol = max(Volume_inM3);

% -------------------------------------------------------------------------
f4=figure(4); hold on
plot([t(1) t(end)],[minLVVol minLVVol]*1e6, 'k--','LineWidth',1)
plot([t(1) t(end)],[maxLVVol maxLVVol]*1e6, 'k--','LineWidth',1)
plot(t, Volume_inM3*1e6, 'r-','LineWidth',2)
annotation(f4,'textbox',[0.45 0.85 0.3 0.05],'String',{sprintf('%.2f ml',maxLVVol*1e6)},'EdgeColor','none','FontSize',14);
annotation(f4,'textbox',[0.45 0.25 0.3 0.05],'String',{sprintf('%.2f ml',minLVVol*1e6)},'EdgeColor','none','FontSize',14);
xlabel('$t^*$','Interpreter','latex','FontSize',14)
ylabel('Ventricular volume [ml]','Interpreter','latex','FontSize',14)
xlim([0 1]); ylim([60 160])
xticks([0:0.25:1]); yticks([60:30:160])
set(gca,'FontSize',14)
hold off
% -------------------------------------------------------------------------


%% Generation of STL files

r_shell = sqrt(data(belowBasePlane,1).^2+data(belowBasePlane,2).^2);
theta_shell = atan2(data(belowBasePlane,2),data(belowBasePlane,1));

r_base = sqrt(data(atBasePlane_Moving,1).^2+data(atBasePlane_Moving,2).^2);
theta_base = atan2(data(atBasePlane_Moving,2),data(atBasePlane_Moving,1));

for iTime = 1:nS

    dataNew = data;

    indexStr = num2str(iTime-1);
    fileName = "./Ideal/STL/ventricle_" + indexStr + ".stl";
    
    % Displacement of ventricle shell
    scaleFactorInX = a_t(iTime)/min_a;
    scaleFactorInY = scaleFactorInX;
    scaleFactorInZ = b_t(iTime)/min_b;

    disp_r = (min_a-a_t(iTime))*(r_shell)/(min_a);

    dataNew(belowBasePlane, [1 2]) = (r_shell-disp_r).*[cos(theta_shell) sin(theta_shell)];
    dataNew(belowBasePlane,   3) = scaleFactorInZ * data(belowBasePlane, 3);
    
    % Displacement of ventricle base moving points
    disp_r = (min_a-a_t(iTime))*(r_base-0.018)/(min_a-0.018);

    dataNew(atBasePlane_Moving, [1 2]) = (r_base-disp_r).*[cos(theta_base) sin(theta_base)];
    dataNew(atBasePlane_Moving,   3) = data(atBasePlane_Moving, 3);
    
    dataNew = dataNew/scaling;

    % Create a new triangulation object with the modified vertices
    newMesh = triangulation(connectivity, dataNew);

    fileName
    stlwrite(newMesh, fileName);

end


%% Inlet and outlet

[maxvalue1,maxindex1]=max(fR);
[maxvalue2,maxindex2]=max(fR(0.3*(Nt-1):end));
maxindex2=0.3*(Nt-1)+maxindex2;

vel = (fR/(pi*1.2^2))*1e-2;
ind0 = find(vel(maxindex2:end) < 1e-6 & vel(maxindex2) > -1e-6);
vel(maxindex2+ind0(1):end)=0;

flowR=-fR*1e-6;
flowR(1:maxindex2+ind0(1))=0;


Inlet_velocity = zeros(Nt,2);
Inlet_velocity(:,1) = tt;
Inlet_velocity(:,2) = vel;

Outlet_flowrate = zeros(Nt,2);
Outlet_flowrate(:,1) = tt;
Outlet_flowrate(:,2) = flowR;

writematrix(Inlet_velocity,'./Ideal/InletVelocity.csv')
writematrix(Outlet_flowrate,'./Ideal/OutletFlowRate.csv')


% -------------------------------------------------------------------------
figure; hold on
plot(tt,fR*1e-6,'bo')
plot(tt,vel*(pi*0.012^2),'r--','LineWidth',2)
plot(tt,-flowR,'g--','LineWidth',2)
xlabel('$t^*$','Interpreter','latex','FontSize',14)
ylabel('Flow rate [$m^3$]','Interpreter','latex','FontSize',14)
% xlim([0 1]); ylim([60 180])
% xticks([0:0.25:1]); yticks([60:30:180])
legend('Ventricular flow rate','Inlet','Outlet', 'Interpreter','latex','FontSize',14,'Location','southwest')
set(gca,'FontSize',14)
hold off
% -------------------------------------------------------------------------

