% ===========================================
%  
%  2024, ModelFLOWs group & NuMath group, UPM
%  
%  This program is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
%  
%  This program is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
%  
%  You should have received a copy of the GNU General Public License
%  along with this program.  If not, see <http://www.gnu.org/licenses/>.
% ===========================================

close all; clear all; clc

%% Load STL files

% End systolic and end diastolic volumes
LV_ESV = stlread("./../../Geometry/Ideal/STL/ventricle_0.stl");
LV_EDV = stlread("./../../Geometry/Ideal/STL/ventricle_1340.stl"); % t/T = 0.67

% Scaling if necessary (we want data in meters)
scaling = 1e-3;
data_ESV = LV_ESV.Points * scaling;
data_EDV = LV_EDV.Points * scaling;

figure(1); hold on 
view([10, -10, 10])
trimesh(LV_ESV.ConnectivityList, data_ESV(:, 1), data_ESV(:, 2), data_ESV(:, 3), 'EdgeColor','k', 'FaceColor',[0.8 0.8 0.8]);
trimesh(LV_EDV.ConnectivityList, data_EDV(:, 1), data_EDV(:, 2), data_EDV(:, 3), 'EdgeColor','r', 'FaceColor','none', 'LineWidth',0.1);
daspect([1 1 1])
grid on
set(gca,'ZDir','reverse')
set(gcf,'Position',[50 100 400 600])
hold off


%% Export scaled initial and final mesh

LV_ESV_scaled = triangulation(LV_ESV.ConnectivityList, data_ESV);
fileName = "Ideal_ESV_scaled.stl";
stlwrite(LV_ESV_scaled, fileName);

LV_EDV_scaled = triangulation(LV_EDV.ConnectivityList, data_EDV);
fileName = "Ideal_EDV_scaled.stl";
stlwrite(LV_EDV_scaled, fileName);

%% Export point to point displacement

% Calculate displacement between ESV and EDV (STL files must have same connectivity)
disp_LV = data_EDV - data_ESV;

% Create a table with first the displacements and then the EDV (maximum volume) points
data_export=[disp_LV data_EDV];

fileName='XYZ_displacement.csv';
titles={'Displacement[i]' 'Displacement[j]' 'Displacement[k]' 'X' 'Y' 'Z'};
data_export = array2table(data_export,'VariableNames',titles);

writetable(data_export,fileName)


%% Calculate volume variation from flow rate chart

% Number of time steps for the profiles
Nt = 1001; % VERY IMPORTANT TO MATCH THIS VALUE WITH THE TIME STEPS IN THE CYCLE OF THE SIMULATION
V0 = 67.02; % Initial volume of ventricle [ml]

RawData = readmatrix("./../../Geometry/Ideal/flowrate_chart.csv");
T_period = 1;
dt = T_period/(Nt-1);

% Normalize time with period
timeH     = RawData(:, 1)/T_period;
flowRateH = RawData(:, 2); 

% -----------------------------------------------------------------------------
% Interpolation to obtain equidistant fine database
t = linspace(timeH(1),timeH(end),Nt);
fR = interp1(timeH,flowRateH,t,'spline');

% -----------------------------------------------------------------------------
% Correction of flow rate difference between diastole and systole
FF = griddedInterpolant(t, fR);
F = @(tau) FF(tau);
index_sys = find(fR<0);
volume_diff = abs(integral(F,t(1),t(end)));

while volume_diff > 1e-3
    
    volume_sum = volume_diff/(t(end-1)-t(index_sys(1)));
    
    if abs(fR(index_sys(1):end-1))<volume_sum
        ('Positive flow rate introduced in systole')
        return
    end
    fR(index_sys(1):end-1)=fR(index_sys(1):end-1)+volume_sum;
    
    FF = griddedInterpolant(t, fR);
    F = @(tau) FF(tau);

    if abs(integral(F,t(1),t(end))) > volume_diff
        ('Converged')
        break
    end

    volume_diff = abs(integral(F,t(1),t(end)));
    
end

% -----------------------------------------------------------------------------
figure(2); hold on
plot(timeH,flowRateH, 'bo','MarkerSize',5,'MarkerFaceColor','b')
plot(t,fR, 'r-','LineWidth',2)
xlabel('$t^{*}$','Interpreter','latex'); ylabel('Ventricular flow rate [ml/s]','Interpreter','latex')
legend('Original','Interpolated')
hold off
% -----------------------------------------------------------------------------


% Calculation of Volume Variation through the cycle

VolumeVariation = zeros(Nt,1);
for i = 1:Nt
    VolumeVariation(i) = integral(F, t(1), t(i));
end

Volume_inM3 = (V0 + VolumeVariation) * 1e-6;

minLVVol = min(Volume_inM3);
maxLVVol = max(Volume_inM3);

% -------------------------------------------------------------------------
f4=figure(3); hold on
plot([t(1) t(end)],[minLVVol minLVVol]*1e6, 'k--','LineWidth',1)
plot([t(1) t(end)],[maxLVVol maxLVVol]*1e6, 'k--','LineWidth',1)
plot(t, Volume_inM3*1e6, 'r-','LineWidth',2)
annotation(f4,'textbox',[0.45 0.85 0.3 0.05],'String',{sprintf('%.2f ml',maxLVVol*1e6)},'EdgeColor','none','FontSize',14);
annotation(f4,'textbox',[0.45 0.25 0.3 0.05],'String',{sprintf('%.2f ml',minLVVol*1e6)},'EdgeColor','none','FontSize',14);
xlabel('$t^*$','Interpreter','latex','FontSize',14)
ylabel('Ventricular volume [ml]','Interpreter','latex','FontSize',14)
xlim([0 1]); ylim([60 160])
xticks([0:0.25:1]); yticks([60:30:160])
set(gca,'FontSize',14)
hold off
% -------------------------------------------------------------------------


%% Create and export boundary condition tables

% Normalize Volume Variation
Volume_inM3 = (Volume_inM3-minLVVol)/(maxLVVol-minLVVol);

% Calculate the incremental volume variation
dVol = [0; diff(Volume_inM3)];

data_export=[t' dVol];

fileName=sprintf('Incremental_VolumeVariation_DT-%.0e.csv',dt);
titles={'t' 'dVol'};
data_export = array2table(data_export,'VariableNames',titles);

writetable(data_export,fileName)

% -------------------------------------------------------------------------
figure(4)
plot(t',dVol,'b-','LineWidth',2)
xlabel('$t^*$','Interpreter','latex','FontSize',14)
ylabel('Incremental Volume Variation','Interpreter','latex','FontSize',14)
set(gca,'FontSize',14)
% -------------------------------------------------------------------------


% Calculate inlet velocity

[maxvalue1,maxindex1]=max(fR);
[maxvalue2,maxindex2]=max(fR(0.3*(Nt-1):end));
maxindex2=0.3*(Nt-1)+maxindex2;

velin = (fR/(pi*1.2^2))*1e-2;
ind0 = find(velin(maxindex2:end) < 1e-6 & velin(maxindex2) > -1e-6);
velin(maxindex2+ind0(1):end)=0;

data_export=[t' velin'];

fileName=sprintf('InletVelocity_DT-%.0e.csv',dt);
titles={'t' 'velin'};
data_export = array2table(data_export,'VariableNames',titles);

writetable(data_export,fileName)


% Calculate outlet flow rate

fRout=-fR*1e-6;
fRout(1:maxindex2+ind0(1))=0;

data_export=[t' fRout'];

fileName=sprintf('OutletFlowRate_DT-%.0e.csv',dt);
titles={'t' 'fRout'};
data_export = array2table(data_export,'VariableNames',titles);

writetable(data_export,fileName)

% -------------------------------------------------------------------------
figure(5); hold on
plot(t,fR*1e-6,'bo')
plot(t,velin*(pi*0.012^2),'r--','LineWidth',2)
plot(t,-fRout,'g--','LineWidth',2)
xlabel('$t^*$','Interpreter','latex','FontSize',14)
ylabel('Flow rate [$m^3$]','Interpreter','latex','FontSize',14)
% xlim([0 1]); ylim([60 180])
% xticks([0:0.25:1]); yticks([60:30:180])
legend('Ventricular flow rate','Inlet','Outlet', 'Interpreter','latex','FontSize',14,'Location','southwest')
set(gca,'FontSize',14)
hold off
% -------------------------------------------------------------------------

