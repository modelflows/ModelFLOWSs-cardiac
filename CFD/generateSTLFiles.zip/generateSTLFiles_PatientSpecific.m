% ===========================================
%  
%  2024, ModelFLOWs group & NuMath group, UPM
%  
%  This program is free software: you can redistribute it and/or modify
%  it under the terms of the GNU General Public License as published by
%  the Free Software Foundation, either version 3 of the License, or
%  (at your option) any later version.
%  
%  This program is distributed in the hope that it will be useful,
%  but WITHOUT ANY WARRANTY; without even the implied warranty of
%  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
%  GNU General Public License for more details.
%  
%  You should have received a copy of the GNU General Public License
%  along with this program.  If not, see <http://www.gnu.org/licenses/>.
% ===========================================

close all; clear all; clc
mkdir './PatientSpecific/STL'


%% Load your STL file

initialMesh = stlread("./PatientSpecific/PatientSpecific.stl");
stlwrite(initialMesh,"./PatientSpecific/STL/ventricle_0.stl",'text');

% Code in meters, scaling if necessary
scaling = 1;
data = initialMesh.Points*scaling;
connectivity = initialMesh.ConnectivityList;

% Initial volume of the LV
[volumeMin, ~] = triangulationVolume(initialMesh.ConnectivityList, initialMesh.Points(:,1), initialMesh.Points(:,2), initialMesh.Points(:,3));
volumeMin = volumeMin*1e6;

% Compute normals for each face
faceNormals = faceNormal(initialMesh);

% Identify the minimum y-axis point
minYPoint = min(initialMesh.Points(:, 2));

% -----------------------------------------------------------------------------
figure(1); hold on
view([0,-60])
trimesh(connectivity, data(:, 1), data(:, 2), data(:, 3), 'EdgeColor','k', 'FaceColor',[0.8 0.8 0.8]);
xlabel('X'); ylabel('Y'); zlabel('Z')
daspect([1 1 1])
grid on
set(gca,'YDir','reverse')
set(gcf,'Position',[50 100 400 600])
hold off
% -----------------------------------------------------------------------------


%% Classification of vertices

% Sort points for moving and static parts
movingPoints = find( data(:, 2) <  1e-10);
staticPoints = find( data(:, 2) >  1e-10);

% -----------------------------------------------------------------------------
colormap_map = colormap(parula);
coldest_color = colormap_map(1, :);

figure(2); hold on
view([0,-60])
h = trimesh(connectivity, data(:, 1), data(:, 2), data(:, 3), 'EdgeColor','k');
xlabel('X'); ylabel('Y'); zlabel('Z')
daspect([1 1 1])
grid on
set(gca,'YDir','reverse')
set(gcf,'Position',[50 100 400 600])
% Moving
normalized_y = 1-(data(movingPoints, 2) - min(data(movingPoints, 2))) / (max(data(movingPoints, 2)) - min(data(movingPoints, 2))); 
vertex_colors = interp1(linspace(0, 1, size(colormap_map, 1)), colormap_map, normalized_y);
scatter3(data(movingPoints, 1), data(movingPoints, 2), data(movingPoints, 3), 36, vertex_colors, 'filled');
% Static
scatter3(data(staticPoints, 1), data(staticPoints, 2), data(staticPoints, 3), 36, coldest_color, 'filled');
% -----------------------------------------------------------------------------


%% Flow rate chart

RawData = readmatrix("./PatientSpecific/flowrate_chart.csv");
T_period = 1;
Nt = 2001;

% Normalize time with period
timeH     = RawData(:, 1)/T_period;
flowRateH = RawData(:, 2); 

% -----------------------------------------------------------------------------
% Interpolation to obtain equidistant fine database
tt=linspace(timeH(1),timeH(end),Nt);
fR = interp1(timeH,flowRateH,tt,'spline');

% -----------------------------------------------------------------------------
% Correction of flow rate difference between diastole and systole
FF = griddedInterpolant(tt, fR);
F = @(tau) FF(tau);
index_sys = find(fR<0);
volume_diff = abs(integral(F,tt(1),tt(end)));

while volume_diff > 1e-3
    
    volume_sum = volume_diff/(tt(end-1)-tt(index_sys(1)));
    
    if abs(fR(index_sys(1):end-1))<volume_sum
        ('Positive flow rate introduced in systole')
        return
    end
    fR(index_sys(1):end-1)=fR(index_sys(1):end-1)+volume_sum;
    
    FF = griddedInterpolant(tt, fR);
    F = @(tau) FF(tau);

    if abs(integral(F,tt(1),tt(end))) > volume_diff
        ('Converged')
        break
    end

    volume_diff = abs(integral(F,tt(1),tt(end)));
    
end

% -----------------------------------------------------------------------------
figure(3); hold on
plot(timeH,flowRateH, 'bo','MarkerSize',5,'MarkerFaceColor','b')
plot(tt,fR, 'r-','LineWidth',2)
xlabel('$t^{*}$','Interpreter','latex'); ylabel('Ventricular flow rate [ml/s]','Interpreter','latex')
legend('Original','Interpolated')
hold off
% -----------------------------------------------------------------------------


%% Contruct volume with the desired time step

% Number of STL files to create
nS = 501;

t = linspace(tt(1), tt(end), nS);

VolumeVariation = zeros(1, nS);
for i = 1:nS
    VolumeVariation(i) = integral(F, t(1), t(i));
end
VolumeVariation = (volumeMin + VolumeVariation);

minLVVol = min(VolumeVariation);
maxLVVol = max(VolumeVariation);

% -------------------------------------------------------------------------
f4=figure(4); hold on
plot([t(1) t(end)],[minLVVol minLVVol], 'k--','LineWidth',1)
plot([t(1) t(end)],[maxLVVol maxLVVol], 'k--','LineWidth',1)
plot(t, VolumeVariation, 'r-','LineWidth',2)
annotation(f4,'textbox',[0.45 0.85 0.3 0.05],'String',{sprintf('%.2f ml',maxLVVol)},'EdgeColor','none','FontSize',14);
annotation(f4,'textbox',[0.45 0.25 0.3 0.05],'String',{sprintf('%.2f ml',minLVVol)},'EdgeColor','none','FontSize',14);
xlabel('$t^*$','Interpreter','latex','FontSize',14)
ylabel('Ventricular volume [ml]','Interpreter','latex','FontSize',14)
xlim([0 1]); ylim([120 220])
xticks([0:0.25:1]); yticks([120:30:220])
set(gca,'FontSize',14)
hold off
% -------------------------------------------------------------------------


%% Generation of STL files

prevVolume = volumeMin;

for iTime = 1:nS-1

    indexStr = num2str(iTime);
    fileName = "./PatientSpecific/STL/ventricle_" + indexStr + ".stl";
    
    % Optimization loop
    targetVolume = VolumeVariation( iTime+1 );
    totalVolume = 0;

    % Is the volume increasing, decreasing or equal?
    if prevVolume < targetVolume
        displacementFactorLow  =  0.;
        displacementFactorHigh =  1.;
    elseif prevVolume > targetVolume
        displacementFactorLow  = -1.;
        displacementFactorHigh =  0.;
    else
        displacementFactorLow  =  0.;
        displacementFactorHigh =  0.;
    end

    tolerance = 0.001;
    iteration = 0;
    
    while abs(targetVolume-totalVolume) > tolerance % Adjust tolerance as needed
    
        % Calculate the displacement for each vertex using midpoint of the interval
        displacementFactorMid = (displacementFactorLow + displacementFactorHigh) / 2;
    
        % Calculate the displacement for each vertex
        displacement = zeros(size(initialMesh.Points));
    
        for i = 1:size(initialMesh.Points, 1)
            vertex_faces = vertexAttachments(initialMesh, i);
            vertex_faces = cell2mat(vertex_faces);
            normal = mean(faceNormals(vertex_faces, :), 1);
            y = initialMesh.Points(i, 2);
            displacement(i, :) = normal .* max(0, y / minYPoint) * 1e-2 * displacementFactorMid;
        end
    
        % Apply displacement to vertices
        newMeshPoints = initialMesh.Points + displacement;
    
        % Create a new triangulation object with the modified vertices
        newMesh = triangulation(connectivity, newMeshPoints);
    
        [totalVolume, ~] = triangulationVolume(newMesh.ConnectivityList, newMesh.Points(:,1), newMesh.Points(:,2), newMesh.Points(:,3));
        totalVolume = totalVolume*1e6;    

        if totalVolume > targetVolume
            displacementFactorHigh = displacementFactorMid;
        else
            displacementFactorLow = displacementFactorMid;
        end
    
        % Increment iteration counter
        iteration = iteration + 1;
        deltaVolume = totalVolume - targetVolume;
    
    end
    
    initialMesh = newMesh;
    prevVolume = targetVolume;

    % Save the modified mesh to a new .stl file
    fileName
    stlwrite(newMesh,fileName,'text');

end


%% Inlet and outlet

[maxvalue1,maxindex1]=max(fR);
[maxvalue2,maxindex2]=max(fR(0.3*(Nt-1):end));
maxindex2=0.3*(Nt-1)+maxindex2;

vel = (fR/(pi*1.2^2))*1e-2;
ind0 = find(vel(maxindex2:end) < 1e-6 & vel(maxindex2) > -1e-6);
vel(maxindex2+ind0(1):end)=0;

flowR=-fR*1e-6;
flowR(1:maxindex2+ind0(1))=0;


Inlet_velocity = zeros(Nt,2);
Inlet_velocity(:,1) = tt;
Inlet_velocity(:,2) = vel;

Outlet_flowrate = zeros(Nt,2);
Outlet_flowrate(:,1) = tt;
Outlet_flowrate(:,2) = flowR;

writematrix(Inlet_velocity,'./PatientSpecific/InletVelocity.csv')
writematrix(Outlet_flowrate,'./PatientSpecific/OutletFlowRate.csv')


% -------------------------------------------------------------------------
figure; hold on
plot(tt,fR*1e-6,'bo')
plot(tt,vel*(pi*0.012^2),'r--','LineWidth',2)
plot(tt,-flowR,'g--','LineWidth',2)
xlabel('$t^*$','Interpreter','latex','FontSize',14)
ylabel('Flow rate [$m^3$]','Interpreter','latex','FontSize',14)
% xlim([0 1]); ylim([60 180])
% xticks([0:0.25:1]); yticks([60:30:180])
legend('Ventricular flow rate','Inlet','Outlet', 'Interpreter','latex','FontSize',14,'Location','southwest')
set(gca,'FontSize',14)
hold off
% -------------------------------------------------------------------------

